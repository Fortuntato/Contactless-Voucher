﻿namespace ContactlessLoyalty.Enumeration
{
    public enum SchemeLimit
    {
        WembleyEmporium = 9
    }
}
